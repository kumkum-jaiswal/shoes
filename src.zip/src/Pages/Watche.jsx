const Watche = () => {
    return ( 
        <>
            <h1>Watch</h1>
        </>
     );
}
 
export default Watche;
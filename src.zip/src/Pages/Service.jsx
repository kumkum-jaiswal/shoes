const Service = () => {
    return ( 
        <>
            <h1>service</h1>
        </>
     );
}
 
export default Service;
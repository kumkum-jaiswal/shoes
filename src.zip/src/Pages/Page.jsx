const Page = () => {
    return ( 
        <>
            <h1>page</h1>
        </>
     );
}
 
export default Page;
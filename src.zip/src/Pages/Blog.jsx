const Blog = () => {
    return ( 
        <>
            <h1>blog</h1>
        </>
     );
}
 
export default Blog;
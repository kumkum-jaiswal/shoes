import axios from "axios";
import { useEffect, useState } from "react";
import Carousel from 'react-bootstrap/Carousel';
import Button from 'react-bootstrap/Button';
import Card from 'react-bootstrap/Card';

import { useDispatch } from "react-redux";
import { addcartData } from "../addtocartSlice";



const Home = () => {
    const [mydata,setmydata]=useState([]);
    const dispatch=useDispatch()
    const loaddata=()=>{
        let api="http://localhost:3000/product";
       axios.get(api).then((res)=>{
        setmydata(res.data);
    })
}
useEffect(()=>{
    loaddata();
},[])

const addTocartData=(id,name,cate,brand,price,desc,image)=>{
  dispatch(addcartData({id:id,name:name,category:cate,brand:brand,
                         price:price,description:desc,image:image}))

}
const ans=mydata.map((key)=>{
    return(
        <>
        
        <Card style={{ width: "250px",marginTop:"20px" }}>
      <Card.Img variant="top" src={key.image} />
      <Card.Body>
        <Card.Title style={{textAlign:"center", color:"rgb(163, 6, 13)"}}>{key.name}</Card.Title>
        <h3 style={{color:"navy",fontSize:"15px"}}>Brand:{key.brand}</h3>
     
        <h3 style={{color:"navy",fontSize:"15px"}}>For:{key.category}</h3>
        <Card.Text>
          {key.description}
        </Card.Text>
        <Button variant="primary" onClick={()=>{
          addTocartData(key.id,key.name,key.category,key.brand,key.price,key.description)
        }}>Add to cart</Button>
      </Card.Body>
    </Card>
    

        </>
    )
})
    return ( 
        <>
         <Carousel>
      <Carousel.Item>
        <img src="https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwe2d1674c/images/homepage/All_Banners/New_arrivals_D.jpg"style={{width:"100%",height:"500px"}}/>
       
      </Carousel.Item>
      <Carousel.Item>
      <img src='https://www.titan.co.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Library-Sites-TitanSharedLibrary/default/dwd025a10d/images/homepage/All_Banners/BestSellers_D.jpg' style={{width:"100%",height:"500px"}}/>
       
      </Carousel.Item>
      <Carousel.Item>
      <img src='https://www.fastrack.in/dw/image/v2/BKDD_PRD/on/demandware.static/-/Library-Sites-FastrackSharedLibrary/default/dw7089cf8d/images/homepage/desktop/FT_Vyb2.0_D.jpg' style={{width:"100%",height:"500px"}}/>
       
      </Carousel.Item>
    </Carousel>
    <div id="card1">
        <h1>Our Premium Watch Collection</h1>
    </div>
    <div id="homeproduct">
        {ans}
    </div>
        </>
     );
}
 
export default Home;
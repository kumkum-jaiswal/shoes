const Sale = () => {
    return ( 
        <>
            <h1>sale</h1>
        </>
     );
}
 
export default Sale;
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import NavDropdown from 'react-bootstrap/NavDropdown';
import { FaUser } from "react-icons/fa";
import { FaShoppingCart } from "react-icons/fa";
import { IoSearch } from "react-icons/io5";
import { useSelector } from 'react-redux';
import { Link } from 'react-router-dom';

const TopMenu = () => {
  const MyData=useSelector((state)=>state.addCart.cart);
  console.log(MyData)
  const DataCount=MyData.length;
    return ( 
        <>
        <div id='topmenu'>
        <Navbar collapseOnSelect expand="lg" className="bg-body-tertiary">
      <Container>
        <Navbar.Brand href="#home">
          <img src='public/img/ecom.png'/>
        </Navbar.Brand>
        <Navbar.Toggle aria-controls="responsive-navbar-nav" />
        <Navbar.Collapse id="responsive-navbar-nav">
          <Nav className="me-auto">
            <Nav.Link as={Link} to ="home">Home</Nav.Link>
            <Nav.Link as={Link} to ="service">SERVICES</Nav.Link>
            <Nav.Link as={Link} to ="product">PRODUCTS</Nav.Link>
            <Nav.Link as={Link} to ="watch">WATCHES</Nav.Link>
            <Nav.Link as={Link} to ="sale">SALE</Nav.Link>
            <Nav.Link as={Link} to ="blog">BLOG</Nav.Link>
            
            

           
            <NavDropdown title="CATEGORY" id="collapsible-nav-dropdown">
              <NavDropdown.Item href="#action/3.1">Kids Watches</NavDropdown.Item>
              <NavDropdown.Item href="#action/3.2">
                Mens Watches
              </NavDropdown.Item>
              <NavDropdown.Item href="#action/3.3">Women Watches</NavDropdown.Item>
              <NavDropdown.Divider />
              <NavDropdown.Item href="#action/3.4">
               Premium Watches
              </NavDropdown.Item>
            </NavDropdown>
          </Nav>
          <Nav>
          <Nav.Link href="#deets">
          <IoSearch />
            </Nav.Link>
            <Nav.Link href="#deets">
            <FaShoppingCart />
            {DataCount<=0?"":<span>{DataCount}</span>}
            
            </Nav.Link>
            <Nav.Link  href="#memes">
            <FaUser />
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
      </Container>
    </Navbar>
    </div>
        </>
     );
}
 
export default TopMenu;
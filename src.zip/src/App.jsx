import { BrowserRouter, Routes, Route } from "react-router-dom";
import Layout from "./Component/Layout";
import Home from "./Pages/Home";
import Service from "./Pages/Service";
import Watche from "./Pages/Watche";
import Products from "./Pages/Products";
import Sale from "./Pages/Sale";
import Blog from "./Pages/Blog";
import Page from "./Pages/Page";



const App = () => {
  return ( 
    <>
    {/* <Layout/> */}
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout/>}>
        <Route index element={<Home/>}/>
        <Route path="/home" element={<Home/>}/>
        <Route path="/Service" element={<Service/>}/>
        <Route path="/Product" element={<Products/>}/>
        <Route path="/watch" element={<Watche/>}/>
        <Route path="/sale" element={<Sale/>}/>
        <Route path="/blog" element={<Blog/>}/>
        <Route path="/page" element={<Page/>}/>

        </Route>
      </Routes>
    </BrowserRouter>
    </>
   );
}
 
export default App;